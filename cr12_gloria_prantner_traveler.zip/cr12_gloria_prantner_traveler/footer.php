<?php wp_footer(); ?>
<footer class="page-footer font-small bg-dark text-light">
    <div class="footer-copyright text-center py-3">© 2020 Copyright: Gloria Prantner</div>
</footer>

</body>

</html>