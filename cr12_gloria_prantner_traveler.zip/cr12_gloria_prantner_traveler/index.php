<?php get_header(); ?>


<main class="container-fluid mx-auto"> 
    <div class="row justify-content-center">
        <?php if(have_posts()) : ?>

        <?php while(have_posts()) : the_post(); ?>

    <div class="col-lg-5 col-md-4 mb-4 m-1">
        <a href="<?php the_permalink(); ?>">
        <div class="card">
        <?php if(has_post_thumbnail()) : ?>
        <div class="img-container"><?php the_post_thumbnail(); ?></div>
        <?php endif; ?>
            <div class="card-body">
                <h5 class="card-title"><?php the_title(); ?></h5>
                <p class="card-text"><?php the_excerpt(); ?></p>
            </div>
        </div>
        </a>
    </div>


        <?php endwhile; ?>

        <?php else :?>

        <p>No posts found</p>
        <?php endif; ?>
    </div>

<?php get_footer(); ?>