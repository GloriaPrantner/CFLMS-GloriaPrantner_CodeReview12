<?php get_header(); ?>
<div class="container">

       <?php if(have_posts()) : ?>

       <?php while(have_posts()) : the_post(); ?>
       
        <h3 class="mt-5 text-center mb-4">  <?php the_title(); ?>  </h3>
        <?php if(has_post_thumbnail()) : ?>
        <div class="img-container"><?php the_post_thumbnail(); ?></div>
        <?php endif; ?>

       <sup>Created: <?php the_time('F j, Y g:i a'); ?></sup>

       <p>Author: <?php the_author(); ?></p>
       
       <p class="mb-5"><?php the_content(); ?></p>


       <?php endwhile; ?>

       <?php else :?>

       <p>No posts found</p>
       <?php endif; ?>
   </div>

 <?php get_footer(); ?>