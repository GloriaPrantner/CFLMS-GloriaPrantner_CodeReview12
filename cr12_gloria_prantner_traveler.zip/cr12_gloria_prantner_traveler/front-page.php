<?php get_header(); ?>


<main class="container-fluid mx-auto"> 
    <section class="bgimage mb-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                    <h1 class="m-5">Travel Blog</h1>
                </div>
            </div>
        </div>
    </section>
    <div class="text-center">
        <h3><b>Welcome to our Tavel Blog!</b></h3>

        <p><b>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis ipsa enim distinctio animi corporis praesentium optio deleniti omnis tenetur perspiciatis a minus magnam voluptas maiores, suscipit odit quas odio ipsam.</b></p>
    </div><hr>
    <div class="container">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis ipsa enim distinctio animi corporis praesentium optio deleniti omnis tenetur perspiciatis a minus magnam voluptas maiores, suscipit odit quas odio ipsam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis ipsa enim distinctio animi corporis praesentium optio deleniti omnis tenetur perspiciatis a minus magnam voluptas maiores, suscipit odit quas odio ipsam.</p>
    </div>
    <br>
    <br>
    <br>
    <br>


</main>
<?php get_footer(); ?>